﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class EmployeeSearch : Form
    {
        public EmployeeSearch()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void EmployeeSearch_Load(object sender, EventArgs e)
        {
            employeeDataGridView.DataSource = this.employeeTableAdapter.GetDataBy("");

        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {
            //retrieving the name gvien by user
            string givenName = nameTextBox.Text;
            
            //updating the data grid view to potential matches given by the user
            employeeDataGridView.DataSource = this.employeeTableAdapter.GetDataBy(givenName);
            
           
        }

        
     

        private void lbDisplayNames_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void employeeDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
