﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeePaySearch
{
    public partial class btnMaxSalary : Form
    {
        public btnMaxSalary()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void btnMaxSalary_Load(object sender, EventArgs e)
        {
           
            employeeDataGridView.DataSource = this.employeeTableAdapter.GetData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal max_pay = (decimal)this.employeeTableAdapter.maxHourlyPay();

             
            employeeDataGridView.DataSource = this.employeeTableAdapter.highestPaidEmployees(); 

            MessageBox.Show("The highest pay an employees is receving is $ " + max_pay.ToString("0.00") + " an hour");
        }

        private void btnMinSalary_Click(object sender, EventArgs e)
        {
            decimal min_pay = (decimal)this.employeeTableAdapter.minHourlyPay();

            employeeDataGridView.DataSource = this.employeeTableAdapter.lowestPaidEmployees();
            MessageBox.Show("The lowest pay an employees is receving is $ " + min_pay.ToString("0.00") + " an hour");

           

        }
    }
}
