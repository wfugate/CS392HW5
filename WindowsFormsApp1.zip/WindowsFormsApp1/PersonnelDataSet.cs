﻿namespace WindowsFormsApp1
{


    partial class PersonnelDataSet
    {
    }
}

namespace WindowsFormsApp1.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
